export class Employee {
    Id: number;
    name: string;
    grade: string;
    baseSalary: number;
    totalSalary: number;
}